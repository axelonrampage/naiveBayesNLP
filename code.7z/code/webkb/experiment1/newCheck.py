import os
import pickle
from collections import  Counter
# inputDirectory='../../dataset/20News/frequencyRatio/testing/alt.atheism/51125'
# ratiowala='../../dataset/20News/frequency/testing/alt.atheism/classtermfrequency'
#
# with open(inputDirectory,'rb') as one:
#     one1=pickle.load(one)
# with open(ratiowala,'rb') as two:
#     two2=pickle.load(two)
# print('Puranawala',one1)
# print("===================================================")
# print(two2)
inputDirectory='../../dataset/20News/classProbability/counterforth/'
for files in os.listdir(inputDirectory):
    fils=open(inputDirectory+files,'rb')
    fileRead=pickle.load(fils)
    print(Counter(fileRead).most_common(100))