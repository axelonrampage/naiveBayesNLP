import re
import pickle
import os
from collections import Counter
import nltk

class FerquencyFunction:

##    def __init__(self):
##        print('constructer called')

    def termFrequency(self,listItem,directory,docType,folderName,fileName):
##        outFileName='output/20_newsgroups/frequency/training/alt.atheism/'+str(fileName)
        outFilePath=directory+'/'+docType+'/'+folderName
        outFileName=outFilePath+'/'+str(fileName)
        termFreq=Counter(listItem)
        with open(outFileName, 'wb') as fp:
            pickle.dump(termFreq, fp)
        if(os.path.exists(outFilePath+"/classtermfrequency")):
            classtermfrequency = open(outFilePath+'/classtermfrequency', 'rb')     
            ctf = pickle.load(classtermfrequency)
            ctf = ctf + termFreq
        else :
            ctf = termFreq
        with open(outFilePath+'/classtermfrequency', 'wb') as dp:
            pickle.dump(ctf, dp)
        
        
        return ctf
