import custom_function
from FerquencyFunction import *
import inspect
from collections import Counter
import nltk
from bs4 import BeautifulSoup

inputDirectory='../../../dataset/webkb/main'
outputFileDirectory='../../../dataset/webkb/experiment1/preprocessed'
outputDirectory='../../../dataset/webkb/experiment1/frequency'
outputEmailDirectory='../../../dataset/webkb/experiment1/email'
docTypeList = os.listdir(inputDirectory)
# CLEANR = re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});')

fnVar=''
def cleanhtml(raw_html):
  cleanr = re.compile('<.*?>')
  cleantext = re.sub(cleanr, '', raw_html)
  return cleantext

for docType in docTypeList:
    folderNameList=os.listdir(inputDirectory+'/'+docType)
    for folderName in folderNameList:
        trainingPath=inputDirectory+'/'+docType+'/'+folderName+'/'
        files = os.listdir(trainingPath)
        print(folderName)

        for targetfile in files:
            filepath=trainingPath+targetfile

            fileData = open(filepath, "r",errors='ignore')
            sentence=fileData.read()

            sentence=BeautifulSoup(sentence, "lxml").text

            word='Last-Modified:'
            document= custom_function.documentAfterToken(word,sentence)

            sentence=cleanhtml(document)

           #  emailArray=custom_function.extractEmail(document)
           #  mainEmailArray={}
           #  mainEmailArray=emailArray
           # with open(outputEmailDirectory+'/'+docType+'/'+folderName+'/'+targetfile, 'wb') as fp:
           #     pickle.dump(mainEmailArray, fp)


            # emailRemoved = custom_function.removeEmail(document)
            numberAndSpecialSymbolRemoved = custom_function.removeNAS(sentence)

            numberAndSpecialSymbolRemoved=numberAndSpecialSymbolRemoved.lower()

            stemmedArray = custom_function.stopWordRemovalAndStemming(numberAndSpecialSymbolRemoved,'english')
            # print('Before html',len(stemmedArray))
            stemmedArray=[word for  word in stemmedArray if len(word)>2]
            # print('StemmedArray',len(stemmedArray))
            # if 'html' in stemmedArray:
            #     print("Found")
            # saveFile=open(outputFileDirectory+'/'+docType+'/'+folderName+'/'+targetfile,'w')
            # saveFile.write(str(stemmedArray))


            A=FerquencyFunction()
            A.termFrequency(stemmedArray,outputDirectory,docType,folderName,targetfile)
        outFilePath=outputDirectory+'/'+docType+'/'+folderName
        classtermfrequency = open(outFilePath+'/classtermfrequency', 'rb')
        ctf = pickle.load(classtermfrequency)
        if(os.path.exists(outputDirectory+'/'+docType+'/'+docType+'termfrequency')):
            docTypetermfrequency = open(outputDirectory+'/'+docType+'/'+docType+"termfrequency", 'rb')
            dtf = pickle.load(docTypetermfrequency)
            dtf = dtf + ctf
        else :
            dtf = ctf
        with open(outputDirectory+'/'+docType+'/'+docType+"termfrequency", 'wb') as dp:
            pickle.dump(dtf, dp)



##dbfile = open('output/20_newsgroups/frequency/training/alt.atheism/classtermfrequency', 'rb')
##classFerq=pickle.load(dbfile)
##print(len(Counter(classFerq).keys())) # equals to list(set(words))
##print(Counter(classFerq).values()) # counts the elements' frequency
