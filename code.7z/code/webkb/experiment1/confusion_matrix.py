import pickle
# import os
import json

inputDirectory='../../dataset/webkb/result/selectedtokensecond'

classes=['course','department','faculty','project','staff','student']
arrLen=len(classes)
confussionMatrix=arr = [[0 for i in range(arrLen)] for j in range(arrLen)]
for className in classes:
    inputPath=inputDirectory+'/'+className
    with open(inputPath, 'rb') as inputClass:
        inputClassResult=pickle.load(inputClass)
    row=classes.index(className)
    for classFileName,resultData in inputClassResult.items():
        if(resultData['result class']!='undifined'):
            col=classes.index(resultData['result class'])
            confussionMatrix[row][col]=confussionMatrix[row][col]+1
with open("result","w") as f:
    f.write(json.dumps(confussionMatrix))
# print(confussionMatrix)
for itemss in confussionMatrix:
    print(itemss)