import random,os
import shutil


## File Transfer

nath = '../../dataset/webkb/student/misc'
files = os.listdir(nath)
print(files)

# files.remove('path.txt')
random.shuffle(files)
cont=int(len(files)*.7)
print(len(files))
print("Count",cont)
testingPath='../dataset/webkb/main/testing/student'
trainingPath='../dataset/webkb/main/training/student'
trainingfiles=files[:cont]
testingfiles=files[cont:]
for targetfile in testingfiles:
    filePath=nath+'/'+targetfile
    shutil.copy2(filePath, testingPath)
for targetfile in trainingfiles:
    filePath=nath+'/'+targetfile
    shutil.copy2(filePath, trainingPath)

## File Transfer End