# -*- coding: utf-8 -*-
"""
Created on Sun Dec  8 17:23:48 2019

@author: Ali Abbas
"""

import pickle
import os
import csv
from collections import Counter

inputDirectory='../../dataset/webkb/frequency/testing'
# cacmTermProbFilePath='../../dataset/webkb/classProbability/countersecond/cacmtermprobability'
# cisiTermProbFilePath='../../dataset/webkb/classProbability/countersecond/cisitermprobability'
# cranTermProbFilePath='../../dataset/webkb/classProbability/countersecond/crantermprobability'
# medTermProbFilePath='../../dataset/webkb/classProbability/countersecond/medtermprobability'
coursetermprobability='../../dataset/webkb/classProbability/counterforth/coursetermprobability'
departmenttermprobability='../../dataset/webkb/classProbability/counterforth/departmenttermprobability'
facultytermprobability='../../dataset/webkb/classProbability/counterforth/facultytermprobability'
projecttermprobability='../../dataset/webkb/classProbability/counterforth/projecttermprobability'
stafftermprobability='../../dataset/webkb/classProbability/counterforth/stafftermprobability'
studenttermprobability='../../dataset/webkb/classProbability/counterforth/studenttermprobability'
outputDirectory='../../dataset/webkb/result/selectedtokensecond'
docTypeList = os.listdir(inputDirectory)

with open(coursetermprobability, "rb") as coursetermprobabilityFile:
    coursetermprobabilityFileTermProb = pickle.load(coursetermprobabilityFile)
coursetermprobabilityFile = {x: y for x, y in coursetermprobabilityFileTermProb.items() if y != 0}
coursetermprobabilityFile = dict(Counter(coursetermprobabilityFileTermProb).most_common(100))
with open(departmenttermprobability, "rb") as departmenttermprobabilityFile:
    departmenttermprobabilityFileTermProb = pickle.load(departmenttermprobabilityFile)
departmenttermprobabilityFile = {x: y for x, y in departmenttermprobabilityFileTermProb.items() if y != 0}
departmenttermprobabilityFile = dict(Counter(departmenttermprobabilityFileTermProb).most_common(100))
with open(facultytermprobability, "rb") as facultytermprobabilityFile:
    facultytermprobabilityFileTermProb = pickle.load(facultytermprobabilityFile)
facultytermprobabilityFile = {x: y for x, y in facultytermprobabilityFileTermProb.items() if y != 0}
facultytermprobabilityFile = dict(Counter(facultytermprobabilityFileTermProb).most_common(100))
with open(projecttermprobability, "rb") as projecttermprobabilityFile:
    projecttermprobabilityFileTermProb = pickle.load(projecttermprobabilityFile)
projecttermprobabilityFile = {x: y for x, y in projecttermprobabilityFileTermProb.items() if y != 0}
projecttermprobabilityFile = dict(Counter(projecttermprobabilityFileTermProb).most_common(100))
with open(stafftermprobability, "rb") as stafftermprobabilityFile:
    stafftermprobabilityFileTermProb = pickle.load(stafftermprobabilityFile)
stafftermprobabilityFile = {x: y for x, y in stafftermprobabilityFileTermProb.items() if y != 0}
stafftermprobabilityFile = dict(Counter(stafftermprobabilityFileTermProb).most_common(100))
# print(stafftermprobabilityFile)
with open(studenttermprobability, "rb") as studenttermprobabilityFile:
    studenttermprobabilityFileTermProb = pickle.load(studenttermprobabilityFile)
studenttermprobabilityFile = {x: y for x, y in studenttermprobabilityFileTermProb.items() if y != 0}
studenttermprobabilityFile = dict(Counter(studenttermprobabilityFileTermProb).most_common(100))

for docType in docTypeList:
    if docType!='testingtermfrequency':
        classPath=inputDirectory+'/'+docType
        files = os.listdir(classPath)
#        outputDict={'File Name':{'cacm','cisi','cran','med','max','result class','result'}}
        outputCounterFilepath=outputDirectory+'/'+docType
        outputExcelFilepath=outputDirectory+'/'+docType+'.csv'
        outputDict={}
        outputList=[]
        for targetfile in files:
            if targetfile!='classtermfrequency':
                filecoursetermprobability = 0
                filedepartmenttermprobability = 0
                filefacultytermprobability = 0
                fileprojecttermprobability = 0
                filestafftermprobability = 0
                filestudenttermprobability = 0
                filePath=classPath+'/'+targetfile
                with open(filePath, 'rb') as fp:
                    fileTermList=pickle.load(fp)
                
                for fileTerm in fileTermList.keys():
                    # if fileTerm in cacmTermProb:
                    #     fileCacm=fileCacm + cacmTermProb[fileTerm]
                    # if fileTerm in cisiTermProb:
                    #     fileCisi=fileCisi + cisiTermProb[fileTerm]
                    # if fileTerm in cranTermProb:
                    #     fileCran=fileCran + cranTermProb[fileTerm]
                    # if fileTerm in medTermProb:
                    #     fileMed=fileMed + medTermProb[fileTerm]
                    if fileTerm in coursetermprobabilityFile:
                        filecoursetermprobability = filecoursetermprobability + coursetermprobabilityFile[fileTerm]
                    if fileTerm in departmenttermprobabilityFile:
                        filedepartmenttermprobability = filedepartmenttermprobability + departmenttermprobabilityFile[
                            fileTerm]
                    if fileTerm in facultytermprobabilityFile:
                        filefacultytermprobability = filefacultytermprobability + facultytermprobabilityFile[fileTerm]
                    if fileTerm in projecttermprobabilityFile:
                        fileprojecttermprobability = fileprojecttermprobability + projecttermprobabilityFile[fileTerm]
                    if fileTerm in stafftermprobabilityFile:
                        filestafftermprobability = filestafftermprobability + stafftermprobabilityFile[fileTerm]
                    if fileTerm in studenttermprobabilityFile:
                        filestudenttermprobability = filestudenttermprobability + studenttermprobabilityFile[fileTerm]

                maxArray=[]
                maxValue=0
                # if fileCacm !=0:
                #     maxArray.append(fileCacm)
                # if fileCisi !=0:
                #     maxArray.append(fileCisi)
                # if fileCran !=0:
                #     maxArray.append(fileCran)
                # if fileCacm !=0:
                #     maxArray.append(fileCacm)
                # if fileMed !=0:
                #     maxArray.append(fileMed)
                if filecoursetermprobability != 0:
                    maxArray.append(filecoursetermprobability)
                if filedepartmenttermprobability != 0:
                    maxArray.append(filedepartmenttermprobability)
                if filefacultytermprobability != 0:
                    maxArray.append(filefacultytermprobability)
                if fileprojecttermprobability != 0:
                    maxArray.append(fileprojecttermprobability)
                if filestafftermprobability != 0:
                    maxArray.append(filestafftermprobability)
                if filestudenttermprobability != 0:
                    maxArray.append(filestudenttermprobability)

                if len(maxArray) != 0:
                    maxValue=max(maxArray)
                    
                    # if maxValue == fileCacm:
                    #     outputClass='cacm'
                    # elif maxValue == fileCisi:
                    #     outputClass='cisi'
                    # elif maxValue == fileCran:
                    #     outputClass='cran'
                    # elif maxValue == fileMed:
                    #     outputClass='med'
                    if maxValue == filecoursetermprobability:
                        outputClass = 'course'
                    elif maxValue == filedepartmenttermprobability:
                        outputClass = 'department'
                    elif maxValue == filefacultytermprobability:
                        outputClass = 'faculty'
                    elif maxValue == fileprojecttermprobability:
                        outputClass = 'project'
                    elif maxValue == filestafftermprobability:
                        outputClass = 'staff'
                    elif maxValue == filestudenttermprobability:
                        outputClass = 'student'


                    if outputClass == docType:
                        outputValue=True
                    else :
                        outputValue=False
                else :
                    outputClass='undifined'
                    outputValue='undifined'
                outputDict.update({targetfile:{'course':filecoursetermprobability,'department':filedepartmenttermprobability,
                                               'faculty':filefacultytermprobability,
                                               'project':fileprojecttermprobability,'staff':filestafftermprobability,
                                               'student':filestudenttermprobability,

                                        'maxValue' : maxValue,'result class' : outputClass,'result' : outputValue}})
                outputList.append((filecoursetermprobability,filedepartmenttermprobability,
                                   filefacultytermprobability,fileprojecttermprobability,filestafftermprobability,
                                   filestudenttermprobability,maxValue,outputClass,outputValue))
        with open(outputCounterFilepath, 'wb') as fp:
            pickle.dump(outputDict, fp)
        with open(outputExcelFilepath, 'w') as exf:
            wr = csv.writer(exf, dialect='excel')
            wr.writerows(outputList)
print('DOne')