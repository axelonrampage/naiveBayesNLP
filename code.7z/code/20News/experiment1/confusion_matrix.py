import pickle
# import os
import json
mostCommon=100
inputDirectory='../../../dataset/20News/experiment1/selectedFeatures/'+str(mostCommon)+'Features'
resultDir='../../../dataset/20News/experiment1/result/'+str(mostCommon)+'Features/result'

classes=['alt.atheism','comp.graphics','comp.os.ms-windows.misc','comp.sys.ibm.pc.hardware',
         'comp.sys.mac.hardware','comp.windows.x','misc.forsale','rec.autos',
         'rec.motorcycles','rec.sport.baseball','rec.sport.hockey','sci.crypt',
         'sci.electronics','sci.med','sci.space','soc.religion.christian','talk.politics.guns',
         'talk.politics.mideast','talk.politics.misc','talk.religion.misc']
arrLen=len(classes)
confussionMatrix=arr = [[0 for i in range(arrLen)] for j in range(arrLen)]
for className in classes:
    inputPath=inputDirectory+'/'+className
    with open(inputPath, 'rb') as inputClass:
        inputClassResult=pickle.load(inputClass)
    row=classes.index(className)
    for classFileName,resultData in inputClassResult.items():
        if(resultData['result class']!='undifined'):
            col=classes.index(resultData['result class'])
            confussionMatrix[row][col]=confussionMatrix[row][col]+1
with open(resultDir,"w") as f:
    f.write(json.dumps(confussionMatrix))
# print(confussionMatrix)
for itemss in confussionMatrix:
    print(itemss)