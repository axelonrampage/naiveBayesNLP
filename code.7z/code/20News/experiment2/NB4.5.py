import os
import pickle
import time
from collections import Counter

def popp(one,two):
    for x in one:
        if x in two:
            if one[x]>two[x]:
                two.update({x:0})
            else:
                one.update({x:0})


outDir='../../../dataset/20News/experiment2/classProbability/counterforth/PurifiedFiles/'



foldAr=['alt.atheism','comp.graphics','comp.os.ms-windows.misc','comp.sys.ibm.pc.hardware',
        'comp.sys.mac.hardware','comp.windows.x','misc.forsale','rec.autos',
        'rec.motorcycles','rec.sport.baseball','rec.sport.hockey','sci.crypt','sci.electronics',
        'sci.med','sci.space','soc.religion.christian','talk.politics.guns','talk.politics.mideast',
        'talk.politics.misc','talk.religion.misc'
]



alt_atheismtermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/alt.atheismtermprobability'
comp_graphicstermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/comp.graphicstermprobability'
comp_os_ms_windows_misctermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/comp.os.ms-windows.misctermprobability'
comp_sys_ibm_pc_hardwaretermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/comp.sys.ibm.pc.hardwaretermprobability'
comp_sys_mac_hardwaretermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/comp.sys.mac.hardwaretermprobability'
comp_windows_xtermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/comp.windows.xtermprobability'
misc_forsaletermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/misc.forsaletermprobability'
rec_autostermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/rec.autostermprobability'
rec_motorcyclestermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/rec.motorcyclestermprobability'
rec_sport_baseballtermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/rec.sport.baseballtermprobability'
rec_sport_hockeytermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/rec.sport.hockeytermprobability'
sci_crypttermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/sci.crypttermprobability'
sci_electronicstermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/sci.electronicstermprobability'
sci_medtermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/sci.medtermprobability'
sci_spacetermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/sci.spacetermprobability'
soc_religion_christiantermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/soc.religion.christiantermprobability'
talk_politics_gunstermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/talk.politics.gunstermprobability'
talk_politics_mideasttermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/talk.politics.mideasttermprobability'
talk_politics_misctermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/talk.politics.misctermprobability'
talk_religion_misctermprobability='../../../dataset/20News/experiment2/classProbability/counterforth/talk.religion.misctermprobability'

with open(alt_atheismtermprobability, "rb") as alt_atheismtermprobabilityFile:
    alt_atheismtermprobabilityFileTermProb = pickle.load(alt_atheismtermprobabilityFile)
with open(comp_graphicstermprobability, "rb") as comp_graphicstermprobabilityFile:
    comp_graphicstermprobabilityFileTermProb = pickle.load(comp_graphicstermprobabilityFile)
with open(comp_os_ms_windows_misctermprobability, "rb") as comp_os_ms_windows_misctermprobabilityFile:
    comp_os_ms_windows_misctermprobabilityFileTermProb = pickle.load(comp_os_ms_windows_misctermprobabilityFile)
with open(comp_sys_ibm_pc_hardwaretermprobability, "rb") as comp_sys_ibm_pc_hardwaretermprobabilityFile:
    comp_sys_ibm_pc_hardwaretermprobabilityFileTermProb = pickle.load(comp_sys_ibm_pc_hardwaretermprobabilityFile)
with open(comp_sys_mac_hardwaretermprobability, "rb") as comp_sys_mac_hardwaretermprobabilityFile:
    comp_sys_mac_hardwaretermprobabilityFileTermProb = pickle.load(comp_sys_mac_hardwaretermprobabilityFile)
with open(comp_windows_xtermprobability, "rb") as comp_windows_xtermprobabilityFile:
    comp_windows_xtermprobabilityFileTermProb = pickle.load(comp_windows_xtermprobabilityFile)
with open(misc_forsaletermprobability, "rb") as misc_forsaletermprobabilityFile:
    misc_forsaletermprobabilityFileTermProb = pickle.load(misc_forsaletermprobabilityFile)
with open(rec_autostermprobability, "rb") as rec_autostermprobabilityFile:
    rec_autostermprobabilityFileTermProb = pickle.load(rec_autostermprobabilityFile)
with open(rec_motorcyclestermprobability, "rb") as rec_motorcyclestermprobabilityFile:
    rec_motorcyclestermprobabilityFileTermProb = pickle.load(rec_motorcyclestermprobabilityFile)
with open(rec_sport_baseballtermprobability, "rb") as rec_sport_baseballtermprobabilityFile:
    rec_sport_baseballtermprobabilityFileTermProb = pickle.load(rec_sport_baseballtermprobabilityFile)
with open(rec_sport_hockeytermprobability, "rb") as rec_sport_hockeytermprobabilityFile:
    rec_sport_hockeytermprobabilityFileTermProb = pickle.load(rec_sport_hockeytermprobabilityFile)
with open(sci_crypttermprobability, "rb") as sci_crypttermprobabilityFile:
    sci_crypttermprobabilityFileTermProb = pickle.load(sci_crypttermprobabilityFile)
with open(sci_electronicstermprobability, "rb") as sci_electronicstermprobabilityFile:
    sci_electronicstermprobabilityFileTermProb = pickle.load(sci_electronicstermprobabilityFile)
with open(sci_medtermprobability, "rb") as sci_medtermprobabilityFile:
    sci_medtermprobabilityFileTermProb = pickle.load(sci_medtermprobabilityFile)
with open(sci_spacetermprobability, "rb") as sci_spacetermprobabilityFile:
    sci_spacetermprobabilityFileTermProb = pickle.load(sci_spacetermprobabilityFile)
with open(soc_religion_christiantermprobability, "rb") as soc_religion_christiantermprobabilityFile:
    soc_religion_christiantermprobabilityFileTermProb = pickle.load(soc_religion_christiantermprobabilityFile)
with open(talk_politics_gunstermprobability, "rb") as talk_politics_gunstermprobabilityFile:
    talk_politics_gunstermprobabilityFileTermProb = pickle.load(talk_politics_gunstermprobabilityFile)
with open(talk_politics_mideasttermprobability, "rb") as talk_politics_mideasttermprobabilityFile:
    talk_politics_mideasttermprobabilityFileTermProb = pickle.load(talk_politics_mideasttermprobabilityFile)
with open(talk_politics_misctermprobability, "rb") as talk_politics_misctermprobabilityFile:
    talk_politics_misctermprobabilityFileTermProb = pickle.load(talk_politics_misctermprobabilityFile)
with open(talk_religion_misctermprobability, "rb") as talk_religion_misctermprobabilityFile:
    talk_religion_misctermprobabilityFileTermProb = dict(pickle.load(talk_religion_misctermprobabilityFile))
# print(talk_religion_misctermprobabilityFileTermProb)

fileAr=['alt_atheismtermprobabilityFileTermProb','comp_graphicstermprobabilityFileTermProb',
        'comp_os_ms_windows_misctermprobabilityFileTermProb','comp_sys_ibm_pc_hardwaretermprobabilityFileTermProb',
        'comp_sys_mac_hardwaretermprobabilityFileTermProb','comp_windows_xtermprobabilityFileTermProb',
        'misc_forsaletermprobabilityFileTermProb','rec_autostermprobabilityFileTermProb',
        'rec_motorcyclestermprobabilityFileTermProb','rec_sport_baseballtermprobabilityFileTermProb',
        'rec_sport_hockeytermprobabilityFileTermProb','sci_crypttermprobabilityFileTermProb',
        'sci_electronicstermprobabilityFileTermProb','sci_medtermprobabilityFileTermProb',
        'sci_spacetermprobabilityFileTermProb','soc_religion_christiantermprobabilityFileTermProb',
        'talk_politics_gunstermprobabilityFileTermProb','talk_politics_mideasttermprobabilityFileTermProb',
        'talk_politics_misctermprobabilityFileTermProb','talk_religion_misctermprobabilityFileTermProb']
for i in range(19):
    firstFile=eval(fileAr[i])
    print('Sum of Starting FIle',i+1,'-->',sum(firstFile.values()))
    for j in range(i+1,20):
        seconFile=eval(fileAr[j])
        popp(firstFile,seconFile)
    print("After one Iteration")
    print('Sum of File',i+1,'-->',sum(firstFile.values()))

for a in range(20):
    outDirFile=outDir+foldAr[a]+'termprobability'
    openFile=open(outDirFile,'wb')
    # print(outDirFile)
    pickle.dump(eval(fileAr[a]),openFile)
print("Done")












